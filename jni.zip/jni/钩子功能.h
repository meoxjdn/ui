#include "imgui.h"
#include "imgui_internal.h"
#include "backends/imgui_impl_opengl3.h"
#include "backends/imgui_impl_android.h"
#include "ImGui/fonts/Momo.h"
#include "状态管理.h"
#include "Include/Utils.h"
#include "GlossHook/Gloss.h"
#include "R3vMenu/Initialize.h"

static EGLBoolean (*old_eglSwapBuffers)(EGLDisplay, EGLSurface) = nullptr;
static EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
    if (dpy && surface) {
        eglQuerySurface(dpy, surface, EGL_WIDTH, &g_Egl.glWidth);
        eglQuerySurface(dpy, surface, EGL_HEIGHT, &g_Egl.glHeight);
    }
    if (g_Egl.screenWidth == 0) {
        g_Egl.screenWidth = g_Egl.glWidth;
        g_Egl.screenHeight = g_Egl.glHeight;
    }
    if (!g_Initialized && g_Egl.glWidth > 0 && g_Egl.glHeight > 0) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext();
        auto& io = ImGui::GetIO();
        io.DisplaySize = ImVec2((float)g_Egl.glWidth, (float)g_Egl.glHeight);
        io.ConfigFlags |= ImGuiConfigFlags_NavEnableSetMousePos;
        io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
        ImGui::StyleColorsDark();
        ImGui_ImplOpenGL3_Init("#version 100");
        ImFontConfig font_cfg;
        font_cfg.SizePixels = 48.0f;
        io.Fonts->AddFontFromMemoryTTF(Momo, sizeof(Momo), 24.0f, &font_cfg);
        ImGui::GetStyle().ScaleAllSizes(1.8f);
        SetImGuiHitTestCallback(IsPointInImGuiWindow);
        g_Initialized = true;
    }
    if (g_Initialized) {
        ImGui_ImplOpenGL3_NewFrame();
        ImGui::NewFrame();

        AllMenuUpdate();

        ImGui::EndFrame();
        ImGui::Render();
        glViewport(0, 0, g_Egl.glWidth, g_Egl.glHeight);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    }
    return old_eglSwapBuffers ? old_eglSwapBuffers(dpy, surface) : EGL_FALSE;
}

static void InitHooks() {
    GlossInit(true);
    GHandle handle;
    uintptr_t sym;

    handle = GlossOpen("libandroid.so");
    if (handle) {
        sym = GlossSymbol(handle, "ANativeWindow_getWidth", nullptr);
        if (sym) {
            GlossHook((void*)sym, (void*)hook_getWidth, (void**)&old_getWidth);
        }
        sym = GlossSymbol(handle, "ANativeWindow_getHeight", nullptr);
        if (sym) {
            GlossHook((void*)sym, (void*)hook_getHeight, (void**)&old_getHeight);
        }
        GlossClose(handle, false);
    }

    handle = GlossOpen("libinput.so");
    if (handle) {
        sym = GlossSymbol(handle, "_ZN7android11MotionEvent8copyFromEPKS0_b", nullptr);
        if (sym) {
            GlossHook((void*)sym, (void*)hook_input, (void**)&old_input);
        }
        GlossClose(handle, false);
    }

    handle = GlossOpen("libEGL.so");
    if (handle) {
        sym = GlossSymbol(handle, "eglSwapBuffers", nullptr);
        if (sym) {
            GlossHook((void*)sym, (void*)hook_eglSwapBuffers, (void**)&old_eglSwapBuffers);
        }
        GlossClose(handle, false);
    }
}

static void* hack_thread(void*) {
    while (!isLibraryLoaded("libil2cpp.so")) {
        sleep(1);
    }
    InitHooks();
    g_InitDone = true;
    return nullptr;
}
