#include "R3vMain.h"

void AllMenuUpdate() {
    R3vMain();
    Custom::g_NotificationSystem.DrawNotifications();
}