#include <map>
#include <cmath>
#include <string>
#include <algorithm>
#include <chrono>
#include <vector>

inline ImVec2 operator+(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x + rhs.x, lhs.y + rhs.y); }
inline ImVec2 operator-(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x - rhs.x, lhs.y - rhs.y); }
inline ImVec2 operator*(const ImVec2& lhs, float rhs) { return ImVec2(lhs.x * rhs, lhs.y * rhs); }
inline ImVec2 operator/(const ImVec2& lhs, float rhs) { return ImVec2(lhs.x / rhs, lhs.y / rhs); }
inline ImVec2& operator+=(ImVec2& lhs, const ImVec2& rhs) { lhs.x += rhs.x; lhs.y += rhs.y; return lhs; }
inline ImVec2 operator*(const ImVec2& lhs, const ImVec2& rhs) { return ImVec2(lhs.x * rhs.x, lhs.y * rhs.y); }
inline ImVec2& operator*=(ImVec2& lhs, float rhs) { lhs.x *= rhs; lhs.y *= rhs; return lhs; }
inline ImVec4 operator*(const ImVec4& lhs, float rhs) { return ImVec4(lhs.x * rhs, lhs.y * rhs, lhs.z * rhs, lhs.w * rhs); }
inline ImVec4 operator*(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x * rhs.x, lhs.y * rhs.y, lhs.z * rhs.z, lhs.w * rhs.w); }
inline ImVec4 operator+(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x + rhs.x, lhs.y + rhs.y, lhs.z + rhs.z, lhs.w + rhs.w); }
inline ImVec4 operator-(const ImVec4& lhs, const ImVec4& rhs) { return ImVec4(lhs.x - rhs.x, lhs.y - rhs.y, lhs.z - rhs.z, lhs.w - rhs.w); }
inline float ImLength(const ImVec2& vec) { return sqrtf(vec.x * vec.x + vec.y * vec.y); }
inline bool operator<(const ImVec4& lhs, const ImVec4& rhs) { return lhs.x < rhs.x && lhs.y < rhs.y && lhs.z < rhs.z && lhs.w < rhs.w; }
inline bool operator>(const ImVec4& lhs, const ImVec4& rhs) { return lhs.x > rhs.x && lhs.y > rhs.y && lhs.z > rhs.z && lhs.w > rhs.w; }
inline float ImClamp(float v, float mn, float mx) { return v < mn ? mn : (v > mx ? mx : v); }
inline ImVec4 ImClamp(const ImVec4& v, const ImVec4& mn, const ImVec4& mx) { return ImVec4(ImClamp(v.x, mn.x, mx.x), ImClamp(v.y, mn.y, mx.y), ImClamp(v.z, mn.z, mx.z), ImClamp(v.w, mn.w, mx.w)); }

using namespace ImGui;

namespace Custom {
    namespace Colors {
        static ImVec4 accent = ImVec4(147.0f / 255.0f, 190.0f / 255.0f, 66.0f / 255.0f, 1.0f);
        inline float rounding = 4;
        inline ImVec4 background = ImColor(15, 15, 17);
        inline ImVec4 background_widget = ImColor(21, 23, 26);
        inline ImVec4 background_switch = { 28/255.f, 28/255.f, 35/255.f, 1.f };

        inline ImVec4 element_layout = ImColor(21, 21, 29);
        inline ImVec4 element_circle = ImColor(41, 41, 53);
        inline ImVec4 dropdown_selection_layout = ImColor(31, 31, 41);

        namespace backgroundM {
            inline ImVec4 filling = ImColor(12, 12, 12);
            inline ImVec4 stroke = ImColor(24, 26, 36);
            inline float rounding = 6;
        }

        namespace text {
            inline ImVec4 text_active = ImColor(255, 255, 255, 255);
            inline ImVec4 text_hov = ImColor(86, 88, 95, 255);
            inline ImVec4 text = ImColor(100, 100, 100, 255);
        }
    }

    void CricleProgress(const char* name, float progress, float max, float radius, const ImVec2& size) {
        const float tickness = 3.f;
        static float position = 0.f;
        position = progress / max * 6.28f;
        ImGui::GetForegroundDrawList()->PathClear();
        ImGui::GetForegroundDrawList()->PathArcTo(ImGui::GetCursorScreenPos() + size, radius, 0.f, 2.f * IM_PI, 120.f);
        ImGui::GetForegroundDrawList()->PathStroke(ImGui::GetColorU32(Colors::background_widget), 0, tickness);
        ImGui::GetForegroundDrawList()->PathClear();
        ImGui::GetForegroundDrawList()->PathArcTo(ImGui::GetCursorScreenPos() + size, radius, IM_PI * 1.5f, IM_PI * 1.5f + position, 120.f);
        ImGui::GetForegroundDrawList()->PathStroke(ImGui::GetColorU32(Colors::accent), 0, tickness);
        int procent = progress / (int)max * 100;
        std::string procent_str = std::to_string(procent) + "%";
    }

    void GlowText(ImFont* font, float size, const char* label, ImVec2 pos, ImU32 text_color) {
        ImGui::PushFont(font);
        float glow_size = 15.f;
        for (int i = 0; i < glow_size; i++) {
            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 1.f / i / 10);
            ImGui::GetWindowDrawList()->AddText(font, size, pos + ImVec2(i, i), ImGui::GetColorU32(text_color), label);
            ImGui::PopStyleVar();
        }
        ImGui::PopFont();
    }

    struct tab_state {
        float highlight_width = 2.0f;
        ImVec4 text_color = Colors::text::text;
        float bg_width = 0.0f;
        float bg_alpha = 0.30f;
        float corner_radius = 6.0f;
        float highlight_padding_vertical = 4.0f;
        float highlight_padding_horizontal = 8.0f;
        float text_padding_left = 24.0f;
    };

    bool Tab(const char* label, bool selected) {
        if (!label) return false;
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems) return false;
        ImGuiContext& g = *GImGui;
        const ImGuiID id = window->GetID(label);
        const ImVec2 label_size = ImGui::CalcTextSize(label, NULL, true);
        const ImVec2 pos = window->DC.CursorPos;
        const float total_width = ImGui::GetContentRegionAvail().x;
        const float height = label_size.y + 8.0f;
        const ImRect total_bb(pos, pos + ImVec2(total_width, height));
        ImGui::ItemSize(total_bb);
        if (!ImGui::ItemAdd(total_bb, id)) return false;
        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
        bool new_selected = selected;
        if (pressed) {
            new_selected = !selected;
        }
        static std::map<ImGuiID, tab_state> anim_map;
        auto it = anim_map.find(id);
        if (it == anim_map.end()) {
            tab_state init_state;
            init_state.highlight_width = selected ? 4.0f : 2.0f;
            init_state.text_color = selected ? Colors::text::text_active : (hovered ? Colors::text::text_hov : Colors::text::text);
            init_state.bg_width = selected ? total_width : 0.0f;
            anim_map[id] = init_state;
            it = anim_map.find(id);
        }
        tab_state& state = it->second;
        float target_width = selected ? 4.0f : 2.0f;
        float target_bg_width = selected ? total_width : 0.0f;
        ImVec4 target_color;
        if (selected) {
            target_color = Colors::text::text_active;
        } else if (hovered) {
            target_color = Colors::text::text_hov;
        } else {
            target_color = Colors::text::text;
        }
        float speed = 6.0f;
        float delta = g.IO.DeltaTime * speed;
        state.highlight_width = ImLerp(state.highlight_width, target_width, delta);
        state.bg_width = ImLerp(state.bg_width, target_bg_width, delta);
        state.text_color.x = ImLerp(state.text_color.x, target_color.x, delta);
        state.text_color.y = ImLerp(state.text_color.y, target_color.y, delta);
        state.text_color.z = ImLerp(state.text_color.z, target_color.z, delta);
        state.text_color.w = ImLerp(state.text_color.w, target_color.w, delta);
        if (state.bg_width > 0.01f) {
            ImDrawList* draw_list = window->DrawList;
            int segments = 32;
            float segment_width = state.bg_width / segments;
            for (int i = 0; i < segments; i++) {
                float t = (float)i / segments;
                float alpha = state.bg_alpha * (1.0f - t);
                if (alpha <= 0.01f) continue;
                ImU32 segment_color = ImGui::GetColorU32(ImVec4(Colors::accent.x, Colors::accent.y, Colors::accent.z, alpha));
                float x1 = total_bb.Min.x + i * segment_width;
                float x2 = (i == segments - 1) ? total_bb.Min.x + state.bg_width : x1 + segment_width;
                ImDrawFlags flags = ImDrawFlags_RoundCornersNone;
                if (i == 0 && state.bg_width >= total_width) {
                    flags = ImDrawFlags_RoundCornersLeft;
                } else if (i == segments - 1 && state.bg_width >= total_width) {
                    flags = ImDrawFlags_RoundCornersRight;
                } else if (i == 0 && state.bg_width < total_width) {
                    flags = ImDrawFlags_RoundCornersLeft;
                }
                if (state.bg_width >= total_width) {
                    if (i == 0) flags = ImDrawFlags_RoundCornersLeft;
                    else if (i == segments - 1) flags = ImDrawFlags_RoundCornersRight;
                } else {
                    if (i == 0) flags = ImDrawFlags_RoundCornersLeft;
                }
                draw_list->AddRectFilled(ImVec2(x1, total_bb.Min.y), ImVec2(x2, total_bb.Max.y), segment_color, state.corner_radius, flags);
            }
        }
        float highlight_left = total_bb.Min.x + state.highlight_padding_horizontal;
        float highlight_top = total_bb.Min.y + state.highlight_padding_vertical;
        float highlight_bottom = total_bb.Max.y - state.highlight_padding_vertical;
        float highlight_height = highlight_bottom - highlight_top;
        if (highlight_height > 0) {
            ImRect line_bb(ImVec2(highlight_left, highlight_top), ImVec2(highlight_left + state.highlight_width, highlight_bottom));
            ImU32 line_color = selected ? ImGui::GetColorU32(Colors::accent) : ImGui::GetColorU32(ImVec4(Colors::text::text.x, Colors::text::text.y, Colors::text::text.z, 0.5f));
            window->DrawList->AddRectFilled(line_bb.Min, line_bb.Max, line_color);
        }
        float text_offset_x = (state.highlight_width - 2.0f) * 2.0f;
        ImVec2 text_pos = pos + ImVec2(state.text_padding_left + text_offset_x, (height - label_size.y) * 0.5f);
        window->DrawList->AddText(text_pos, ImGui::GetColorU32(state.text_color), label);
        return new_selected;
    }

    inline ImU32 GetColorU32Ex(const ImVec4& col, float alpha = 1.0f) {
        return IM_COL32((int)(col.x * 255), (int)(col.y * 255), (int)(col.z * 255), (int)(col.w * 255 * alpha));
    }

    inline float fixed_speed(float speed) {
        return speed * ImGui::GetIO().DeltaTime;
    }

    struct ButtonState {
        ImVec4 background;
    };

    inline bool Button(const char* label, const ImVec2& size = ImVec2(0, 0)) {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems) return false;
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        float label_size = ImGui::CalcTextSize(label, NULL, true).x;
        float width = ImGui::GetContentRegionAvail().x;
        ImVec2 pos = window->DC.CursorPos;
        ImVec2 final_size = size;
        if (final_size.x <= 0.0f) final_size.x = width;
        if (final_size.y <= 0.0f) final_size.y = ImGui::GetFrameHeight();
        ImRect rect(pos, pos + final_size);
        ImGui::ItemSize(rect, 0);
        if (!ImGui::ItemAdd(rect, id)) return false;
        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(rect, id, &hovered, &held);
        if (pressed) ImGui::MarkItemEdited(id);
        static std::map<ImGuiID, ButtonState> anim;
        ButtonState& state = anim[id];
        state.background = ImLerp(state.background, ImGui::IsItemActive() ? Colors::accent : Colors::element_layout, fixed_speed(8.0f));
        ImDrawList* draw_list = window->DrawList;
        draw_list->AddRectFilled(rect.Min, rect.Max, GetColorU32Ex(state.background), Colors::rounding);
        draw_list->AddText(rect.Min + (rect.GetSize() - ImGui::CalcTextSize(label)) * 0.5f, GetColorU32Ex(Colors::text::text_active), label);
        return pressed;
    }

    struct ToolButtonState {
        bool clicked = false;
        float alpha = 0.f;
    };

    inline bool ToolButton(const char* label, const char* icon, const ImVec2& size = ImVec2(0, 0)) {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems) return false;
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        ImVec2 pos = window->DC.CursorPos;
        ImVec2 final_size = size;
        if (final_size.x <= 0.0f) final_size.x = 50.0f;
        if (final_size.y <= 0.0f) final_size.y = 30.0f;
        ImRect rect(pos, pos + final_size);
        ImGui::ItemSize(rect, 0);
        if (!ImGui::ItemAdd(rect, id)) return false;
        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(rect, id, &hovered, &held);
        static std::map<ImGuiID, ToolButtonState> anim;
        ToolButtonState& state = anim[id];
        if (pressed) state.clicked = true;
        state.alpha = ImClamp(state.alpha + (fixed_speed(8.0f) * (state.clicked ? 1.0f : -1.0f)), 0.0f, 1.0f);
        if (state.alpha >= 0.99f) state.clicked = false;
        ImDrawList* draw_list = window->DrawList;
        draw_list->AddRectFilled(rect.Min, rect.Max, GetColorU32Ex(Colors::backgroundM::stroke), 2.0f);
        ImVec2 text_pos = rect.Min + (rect.GetSize() - ImGui::CalcTextSize(label)) * 0.5f;
        if (icon != NULL && icon[0] != '\0') {
            draw_list->AddText(rect.Min + ImVec2(rect.GetWidth() * 0.18f, (rect.GetHeight() - ImGui::GetFontSize()) * 0.5f), GetColorU32Ex(Colors::text::text), icon);
            text_pos = rect.Min + ImVec2(rect.GetWidth() * 0.7f, (rect.GetHeight() - ImGui::GetFontSize()) * 0.5f);
        } else {
            text_pos = rect.Min + (rect.GetSize() - ImGui::CalcTextSize(label)) * 0.5f;
        }
        draw_list->AddText(text_pos, GetColorU32Ex(Colors::text::text), label);
        draw_list->AddRectFilled(rect.Min, rect.Max, GetColorU32Ex(Colors::accent, 1.0f - state.alpha), 2.0f);
        if (icon != NULL && icon[0] != '\0') {
            draw_list->AddText(rect.Min + ImVec2(rect.GetWidth() * 0.18f, (rect.GetHeight() - ImGui::GetFontSize()) * 0.5f), GetColorU32Ex(Colors::text::text_active, 1.0f - state.alpha), icon);
            draw_list->AddText(rect.Min + ImVec2(rect.GetWidth() * 0.7f, (rect.GetHeight() - ImGui::GetFontSize()) * 0.5f), GetColorU32Ex(Colors::text::text_active, 1.0f - state.alpha), label);
        } else {
            draw_list->AddText(rect.Min + (rect.GetSize() - ImGui::CalcTextSize(label)) * 0.5f, GetColorU32Ex(Colors::text::text_active, 1.0f - state.alpha), label);
        }
        return pressed;
    }

    struct switch_state {
        ImVec4 background, circle, text;
        float background_opticaly, circle_offset;
    };

    bool Switch(const char* label, bool* v, bool align_to_right = false) {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        if (window->SkipItems) return false;
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(label);
        const char* label_end = ImGui::FindRenderedTextEnd(label);
        bool hide_label = (label[0] == '#' && label[1] == '#' && label[2] != '#');
        const char* display_label = hide_label ? label_end : label;
        const ImVec2 label_size = hide_label ? ImVec2(0, 0) : ImGui::CalcTextSize(display_label, NULL, true);
        const float square_sz = 18.0f;
        const float y_size = 18.0f;
        const ImVec2 pos = window->DC.CursorPos;
        const float spacing = 6.0f; 
        const float switch_width = square_sz * 2.0f;
        float switch_x;
        if (hide_label) {
            switch_x = pos.x;
        } else if (align_to_right) {
            switch_x = window->WorkRect.Max.x - switch_width;
        } else {
            switch_x = pos.x + label_size.x + spacing;
        }
        const float total_width = hide_label ? switch_width : (switch_x - pos.x + switch_width);
        const ImRect total_bb(pos, pos + ImVec2(total_width, y_size));
        ImGui::ItemSize(total_bb, 0.0f);
        if (!ImGui::ItemAdd(total_bb, id)) return false;
        bool hovered, held;
        bool pressed = ImGui::ButtonBehavior(total_bb, id, &hovered, &held);
        static std::map<ImGuiID, switch_state> anim;
        auto it_anim = anim.find(id);
        if (it_anim == anim.end()) {
            anim.insert({ id, switch_state() });
            it_anim = anim.find(id);
        }
        it_anim->second.background_opticaly = ImLerp(it_anim->second.background_opticaly, *v ? 0.2f : 1.0f, g.IO.DeltaTime * 6.0f);
        it_anim->second.circle_offset = ImLerp(it_anim->second.circle_offset, *v ? 0.0f : -switch_width, g.IO.DeltaTime * 6.0f);
        it_anim->second.background = ImLerp(it_anim->second.background, *v ? Colors::accent : Colors::background_switch, g.IO.DeltaTime * 6.0f);
        it_anim->second.circle = ImLerp(it_anim->second.circle, *v ? Colors::accent : Colors::text::text, g.IO.DeltaTime * 6.0f);
        it_anim->second.text = ImLerp(it_anim->second.text, *v ? Colors::text::text_active : hovered ? Colors::text::text_hov : Colors::text::text, g.IO.DeltaTime * 6.0f);
        if (pressed) {
            *v = !(*v);
            ImGui::MarkItemEdited(id);
        }
        const ImRect check_bb(ImVec2(switch_x, pos.y + (y_size - square_sz) / 2.0f), ImVec2(switch_x + switch_width, pos.y + (y_size + square_sz) / 2.0f));
        ImDrawList* draw_list = window->DrawList;
        draw_list->AddRectFilled(check_bb.Min, check_bb.Max,ImGui::GetColorU32(ImVec4(it_anim->second.background.x, it_anim->second.background.y, it_anim->second.background.z, it_anim->second.background.w * it_anim->second.background_opticaly)),5.0f);
        draw_list->AddRect(check_bb.Min, check_bb.Max,ImGui::GetColorU32(it_anim->second.background), 5.0f, ImDrawFlags_None, 1.1f);
        const float circle_radius = 5.0f;
        ImVec2 circle_center = ImVec2(check_bb.Max.x - (y_size - it_anim->second.circle_offset) / 2.0f,check_bb.GetCenter().y);
        draw_list->AddCircleFilled(circle_center, circle_radius, ImGui::GetColorU32(it_anim->second.circle), 30);
        if (!hide_label) {
            draw_list->AddText(pos + ImVec2(0.0f, (y_size - label_size.y) / 2.0f),ImGui::GetColorU32(it_anim->second.text),display_label);
        }
        return pressed;
    }

    struct ChildState {
        bool initialized = false;
        ImVec2 header_size;
    };

    bool BeginChild(const char* name, ImGuiID id, const ImVec2& size_arg, bool border, ImGuiWindowFlags flags) {
    ImGuiContext& g = *GImGui;
    ImGuiWindow* parent_window = g.CurrentWindow;
    flags |= ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_ChildWindow;
    flags |= (parent_window->Flags & ImGuiWindowFlags_NoMove);
    const ImVec2 content_avail = ImGui::GetContentRegionAvail();
    ImVec2 size = ImFloor(size_arg);
    if (size.x <= 0.0f) size.x = ImMax(content_avail.x + size.x, 4.0f);
    if (size.y <= 0.0f) size.y = ImMax(content_avail.y + size.y, 4.0f);
    const float header_height = 32.0f;
    const float bottom_padding = 4.0f;
    ImVec2 content_size = ImVec2(size.x, size.y - header_height - bottom_padding);
    ImVec2 window_pos = parent_window->DC.CursorPos;
    ImGui::SetNextWindowPos(window_pos);
    ImGui::SetNextWindowSize(size);
    ImGui::SetNextWindowContentSize(content_size);
    const char* temp_window_name;
    if (name) ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%s_%08X", parent_window->Name, name, id);
    else ImFormatStringToTempBuffer(&temp_window_name, NULL, "%s/%08X", parent_window->Name, id);
    const float backup_border_size = g.Style.ChildBorderSize;
    if (!border) g.Style.ChildBorderSize = 0.0f;
    ImGuiChildFlags child_flags = 0;
    if (border) child_flags |= ImGuiChildFlags_Borders;
    bool ret = ImGui::BeginChild(temp_window_name, size, child_flags, flags);
    g.Style.ChildBorderSize = backup_border_size;
    ImGuiWindow* child_window = g.CurrentWindow;
    child_window->ChildId = id;
    ImDrawList* draw_list = child_window->DrawList;
    ImVec2 win_pos = child_window->Pos;
    ImVec2 win_size = child_window->Size;
    ImU32 accent_color = ImGui::GetColorU32(Colors::accent);
    ImU32 accent_color_50 = ImGui::GetColorU32(ImVec4(Colors::accent.x, Colors::accent.y, Colors::accent.z, 0.5f));
    ImU32 accent_color_0 = ImGui::GetColorU32(ImVec4(Colors::accent.x, Colors::accent.y, Colors::accent.z, 0.0f));
    draw_list->AddRectFilled(win_pos, win_pos + win_size, ImColor(24, 24, 26), 4.0f, ImDrawFlags_RoundCornersAll);
    draw_list->AddRect(win_pos, win_pos + win_size, ImColor(1.0f, 1.0f, 1.0f, 0.03f), 4.0f, ImDrawFlags_RoundCornersAll);
    float gradient_width = ImMin(win_size.x - 115.0f, win_size.x - 20.0f);
    if (gradient_width > 0) {
        draw_list->AddRectFilledMultiColorRounded(win_pos, win_pos + ImVec2(gradient_width, header_height), ImColor(24, 24, 26), accent_color_50, accent_color_0, accent_color_0, accent_color_50, 4.0f, ImDrawFlags_RoundCornersTopLeft);
    }
    draw_list->AddLine(win_pos + ImVec2(1, header_height), win_pos + ImVec2(win_size.x - 1, header_height), ImColor(1.0f, 1.0f, 1.0f, 0.03f));
    if (name) {
        draw_list->AddText(ImGui::GetFont(), 24.0f, win_pos + ImVec2(16, 4), accent_color, name);
    }
    if (g.NavActivateId == id && !(child_flags & ImGuiChildFlags_NavFlattened) && 
        (child_window->DC.NavLayersActiveMask != 0 || child_window->DC.NavWindowHasScrollY)) {
        ImGui::FocusWindow(child_window);
        ImGui::NavInitWindow(child_window, false);
        ImGui::SetActiveID(id + 1, child_window);
        g.ActiveIdSource = ImGuiInputSource_Keyboard;
    }
    ImGui::Dummy(ImVec2(0, header_height + 4.0f));
    return ret;
}

    bool begin_child(const char* str_id, const ImVec2& size_arg, bool border, ImGuiWindowFlags extra_flags) {
        ImGuiWindow* window = ImGui::GetCurrentWindow();
        ImGuiChildFlags child_flags = ImGuiChildFlags_None;
        if (border) child_flags |= ImGuiChildFlags_Borders;
        if (size_arg.x == 0.0f) child_flags |= ImGuiChildFlags_AutoResizeX;
        if (size_arg.y == 0.0f) child_flags |= ImGuiChildFlags_AutoResizeY;
        ImGui::PushStyleVar(ImGuiStyleVar_ItemSpacing, ImVec2(8, 6));
        bool ret = BeginChild(str_id, window->GetID(str_id), size_arg, border, extra_flags | ImGuiWindowFlags_NoMove);
        ImGui::Indent(8.0f);
        return ret;
    }

    bool begin_child(ImGuiID id, const ImVec2& size_arg, bool border, ImGuiWindowFlags extra_flags) {
        IM_ASSERT(id != 0);
        return BeginChild(NULL, id, size_arg, border, extra_flags);
    }

    void EndChild() {
        ImGuiContext& g = *GImGui;
        ImGuiWindow* window = g.CurrentWindow;
        IM_ASSERT(window->Flags & ImGuiWindowFlags_ChildWindow);
        ImGui::Unindent(8.0f);
        ImGui::EndChild();
        ImGui::PopStyleVar();
        g.LogLinePosY = -FLT_MAX;
    }

    struct Notification {
        int id;
        std::string message;
        std::chrono::steady_clock::time_point startTime;
        std::chrono::steady_clock::time_point endTime;
        int type;
    };

    class NotificationSystem {
    public:
        NotificationSystem() : notificationIdCounter(0) {}

        void AddNotification(const std::string& message, int durationMs, int type = 0) {
            auto now = std::chrono::steady_clock::now();
            auto endTime = now + std::chrono::milliseconds(durationMs);
            notifications.push_back({ notificationIdCounter++, message, now, endTime, type });
        }

        void DrawNotifications() {
            auto now = std::chrono::steady_clock::now();
            std::sort(notifications.begin(), notifications.end(),
                [now](const Notification& a, const Notification& b) -> bool {
                    float durationA = std::chrono::duration_cast<std::chrono::milliseconds>(a.endTime - a.startTime).count();
                    float elapsedA = std::chrono::duration_cast<std::chrono::milliseconds>(now - a.startTime).count();
                    float percentageA = (durationA - elapsedA) / durationA;
                    float durationB = std::chrono::duration_cast<std::chrono::milliseconds>(b.endTime - b.startTime).count();
                    float elapsedB = std::chrono::duration_cast<std::chrono::milliseconds>(now - b.startTime).count();
                    float percentageB = (durationB - elapsedB) / durationB;
                    return percentageA < percentageB;
                }
            );
            int currentNotificationPosition = 0;
            for (auto& notification : notifications) {
                if (now < notification.endTime) {
                    float duration = std::chrono::duration_cast<std::chrono::milliseconds>(notification.endTime - notification.startTime).count();
                    float elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - notification.startTime).count();
                    float percentage = (duration - elapsed) / duration * 100.0f;
                    ShowNotification(currentNotificationPosition, notification.message, percentage, notification.type);
                    currentNotificationPosition++;
                }
            }
            notifications.erase(std::remove_if(notifications.begin(), notifications.end(),
                [now](const Notification& notification) { return now >= notification.endTime; }),
                notifications.end());
        }

    private:
        std::vector<Notification> notifications;
        int notificationIdCounter;

        void ShowNotification(int position, const std::string& message, float percentage, int type = 0) {
            float duePercentage = 100.0f - percentage;
            float alpha = percentage > 10.0f ? 1.0f : percentage / 10.0f;
            ImGui::GetStyle().WindowPadding = ImVec2(15, 10);
            ImGui::SetNextWindowPos(ImVec2(duePercentage < 15.f ? duePercentage : 15.f, 15 + position * 90));
            ImGui::Begin(("##NOTIFY" + std::to_string(position)).c_str(), nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoBringToFrontOnFocus);
            ImVec2 pos = ImGui::GetWindowPos();
            ImVec2 region = ImGui::GetContentRegionMax();
            ImVec2 window_size = ImGui::GetWindowSize();
            ImGui::GetWindowDrawList()->AddRectFilledMultiColorExOne(pos, pos + window_size, ImGui::GetColorU32ExOne(Colors::backgroundM::filling, alpha), ImGui::GetColorU32ExOne(Colors::accent, 0.01f), ImGui::GetColorU32ExOne(Colors::accent, 0.01f), ImGui::GetColorU32ExOne(Colors::backgroundM::filling, alpha), 4.0f);
            ImGui::GetWindowDrawList()->AddRectFilled(pos, pos + window_size, ImGui::GetColorU32ExOne(Colors::backgroundM::filling, 0.4f), Colors::rounding);
            ImGui::GetWindowDrawList()->AddRect(pos, pos + window_size, ImGui::GetColorU32ExOne(Colors::backgroundM::stroke, alpha), Colors::rounding);
            if (type == 0)
                CricleProgress("##NOTIFY", percentage, 100, 7.f, ImVec2(ImGui::GetContentRegionMax().x - 40, 11));
            if (type == 1)
                ImGui::GetForegroundDrawList()->AddRectFilled(pos + ImVec2(0, window_size.y - 3), pos + ImVec2(window_size.x * (duePercentage / 100.0f), window_size.y), ImGui::GetColorU32ExOne(Colors::accent, alpha), Colors::rounding);
            ImGui::TextColored(ImColor(ImGui::GetColorU32ExOne(Colors::accent, alpha)), "%s", "[Notification]");
            ImGui::TextColored(ImColor(ImGui::GetColorU32ExOne(Colors::text::text_active, alpha)), "%s", message.c_str());
            ImGui::Dummy(ImVec2(ImGui::CalcTextSize(message.c_str()).x + 15, 5));
            ImGui::End();
        }
    };

    inline NotificationSystem g_NotificationSystem;

    static void ColorEditRestoreH(const float* col, float* H) {
        ImGuiContext& g = *GImGui;
        IM_ASSERT(g.ColorEditCurrentID != 0);
        if (g.ColorEditSavedID != g.ColorEditCurrentID || g.ColorEditSavedColor != ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0))) return;
        *H = g.ColorEditSavedHue;
    }

    static void ColorEditRestoreHS(const float* col, float* H, float* S, float* V) {
        ImGuiContext& g = *GImGui;
        IM_ASSERT(g.ColorEditCurrentID != 0);
        if (g.ColorEditSavedID != g.ColorEditCurrentID || g.ColorEditSavedColor != ImGui::ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0))) return;
        if (*S == 0.0f || (*H == 0.0f && g.ColorEditSavedHue == 1))
            *H = g.ColorEditSavedHue;
        if (*V == 0.0f) *S = g.ColorEditSavedSat;
    }

    struct iconbox_state {
        float line;
    };

    bool icon_box(const char* icon, ImVec2 size, ImU32 color_bg, ImU32 color_icon, ImU32 color_border) {
        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems) return false;
        const ImVec2 pos = window->DC.CursorPos;
        const ImRect rect(pos, pos + size);
        const ImGuiID id = window->GetID(icon);
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        ItemSize(rect, 0.f);
        if (!ItemAdd(rect, id)) return false;
        bool hovered, held, pressed = ButtonBehavior(rect, id, &hovered, &held, NULL);
        static std::map<ImGuiID, iconbox_state> anim;
        iconbox_state& state = anim[id];
        GetWindowDrawList()->AddRectFilled(rect.Min, rect.Max, GetColorU32(color_bg), Colors::rounding);
        GetWindowDrawList()->AddRect(rect.Min, rect.Max, GetColorU32(color_border), Colors::rounding);
        GetWindowDrawList()->AddText(ImGui::GetFont(), size.y * 0.6f, rect.Min + (size - ImGui::CalcTextSize(icon)) * 0.5f, GetColorU32(color_icon), icon);
        return pressed;
    }

    bool color_button(const char* name, ImVec2 size, ImU32 color_bg) {
        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems) return false;
        const ImVec2 pos = window->DC.CursorPos;
        const ImRect rect(pos, pos + size);
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const ImGuiID id = window->GetID(name);
        ItemSize(rect, 0.f);
        if (!ItemAdd(rect, id)) return false;
        bool hovered, held, pressed = ButtonBehavior(rect, id, &hovered, &held, NULL);
        static std::map<ImGuiID, iconbox_state> anim;
        iconbox_state& state = anim[id];
        float rounding = 4.0f;
        GetWindowDrawList()->AddRectFilled(rect.Min, rect.Max, GetColorU32(color_bg), rounding);
        return pressed;
    }

    struct picker_state {
        float hue_bar;
        float alpha_bar;
        float circle;
        ImVec2 circle_move;
    };

    bool ColorPicker4(const char* label, float col[4], ImGuiColorEditFlags flags, const float* ref_col) {
        ImGuiContext& g = *GImGui;
        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems) return false;
        ImDrawList* draw_list = window->DrawList;
        ImGuiStyle& style = g.Style;
        ImGuiIO& io = g.IO;
        const float width = CalcItemWidth();
        g.NextItemData.ClearFlags();
        PushID(label);
        const bool set_current_color_edit_id = (g.ColorEditCurrentID == 0);
        if (set_current_color_edit_id) g.ColorEditCurrentID = window->IDStack.back();
        BeginGroup();
        if (!(flags & ImGuiColorEditFlags_NoSidePreview)) flags |= ImGuiColorEditFlags_NoSmallPreview;
        if (!(flags & ImGuiColorEditFlags_NoOptions)) ColorPickerOptionsPopup(col, flags);
        if (!(flags & ImGuiColorEditFlags_PickerMask_)) flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_PickerMask_) ? g.ColorEditOptions : ImGuiColorEditFlags_DefaultOptions_) & ImGuiColorEditFlags_PickerMask_;
        if (!(flags & ImGuiColorEditFlags_InputMask_)) flags |= ((g.ColorEditOptions & ImGuiColorEditFlags_InputMask_) ? g.ColorEditOptions : ImGuiColorEditFlags_DefaultOptions_) & ImGuiColorEditFlags_InputMask_;
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_PickerMask_));
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_InputMask_));
        if (!(flags & ImGuiColorEditFlags_NoOptions)) flags |= (g.ColorEditOptions & ImGuiColorEditFlags_AlphaBar);
        int components = (flags & ImGuiColorEditFlags_NoAlpha) ? 3 : 4;
        bool alpha_bar = (flags & ImGuiColorEditFlags_AlphaBar) && !(flags & ImGuiColorEditFlags_NoAlpha);
        ImVec2 picker_pos = window->DC.CursorPos;
        float square_sz = GetFrameHeight();
        float bars_width = 15.f;
        float sv_picker_size = ImMax(bars_width * 1, width - (alpha_bar ? 2 : 1) * (bars_width));
        float bar0_pos_x = picker_pos.x + sv_picker_size + 10;
        float bar1_pos_x = bar0_pos_x + bars_width + 10;
        float bars_triangles_half_sz = IM_TRUNC(bars_width * 0.20f);
        float backup_initial_col[4];
        memcpy(backup_initial_col, col, components * sizeof(float));
        float H = col[0], S = col[1], V = col[2];
        float R = col[0], G = col[1], B = col[2];
        if (flags & ImGuiColorEditFlags_InputRGB) {
            ColorConvertRGBtoHSV(R, G, B, H, S, V);
            ColorEditRestoreHS(col, &H, &S, &V);
        } else if (flags & ImGuiColorEditFlags_InputHSV) {
            ColorConvertHSVtoRGB(H, S, V, R, G, B);
        }
        bool value_changed = false, value_changed_h = false, value_changed_sv = false;
        InvisibleButton("sv", ImVec2(sv_picker_size, sv_picker_size));
        if (IsItemActive()) {
            S = ImSaturate((io.MousePos.x - picker_pos.x) / (sv_picker_size - 1));
            V = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size - 1));
            ColorEditRestoreH(col, &H);
            value_changed = value_changed_sv = true;
        }
        if (!(flags & ImGuiColorEditFlags_NoOptions)) OpenPopupOnItemClick("context", ImGuiPopupFlags_MouseButtonRight);
        SetCursorScreenPos(ImVec2(bar0_pos_x, picker_pos.y));
        InvisibleButton("hue", ImVec2(bars_width, sv_picker_size));
        if (IsItemActive()) {
            H = ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size - 1));
            value_changed = value_changed_h = true;
        }
        if (alpha_bar) {
            SetCursorScreenPos(ImVec2(bar1_pos_x, picker_pos.y));
            InvisibleButton("alpha", ImVec2(bars_width, sv_picker_size));
            if (IsItemActive()) {
                col[3] = 1.0f - ImSaturate((io.MousePos.y - picker_pos.y) / (sv_picker_size - 1));
                value_changed = true;
            }
        }
        if (!(flags & ImGuiColorEditFlags_NoLabel)) {
            const char* label_display_end = FindRenderedTextEnd(label);
            if (label != label_display_end) {
                if ((flags & ImGuiColorEditFlags_NoSidePreview)) SameLine(0, style.ItemInnerSpacing.x);
                TextEx(label, label_display_end);
            }
        }
        if (value_changed_h || value_changed_sv) {
            if (flags & ImGuiColorEditFlags_InputRGB) {
                ColorConvertHSVtoRGB(H, S, V, col[0], col[1], col[2]);
                g.ColorEditSavedHue = H;
                g.ColorEditSavedSat = S;
                g.ColorEditSavedID = g.ColorEditCurrentID;
                g.ColorEditSavedColor = ColorConvertFloat4ToU32(ImVec4(col[0], col[1], col[2], 0));
            } else if (flags & ImGuiColorEditFlags_InputHSV) {
                col[0] = H;
                col[1] = S;
                col[2] = V;
            }
        }
        if (value_changed) {
            if (flags & ImGuiColorEditFlags_InputRGB) {
                R = col[0];
                G = col[1];
                B = col[2];
                ColorConvertRGBtoHSV(R, G, B, H, S, V);
                ColorEditRestoreHS(col, &H, &S, &V);
            } else if (flags & ImGuiColorEditFlags_InputHSV) {
                H = col[0];
                S = col[1];
                V = col[2];
                ColorConvertHSVtoRGB(H, S, V, R, G, B);
            }
        }
        const int style_alpha8 = IM_F32_TO_INT8_SAT(style.Alpha);
        const ImU32 col_black = IM_COL32(0, 0, 0, style_alpha8);
        const ImU32 col_white = IM_COL32(255, 255, 255, style_alpha8);
        const ImU32 col_midgrey = IM_COL32(128, 128, 128, style_alpha8);
        const ImU32 col_hues[6 + 1] = { IM_COL32(255,0,0,style_alpha8), IM_COL32(255,255,0,style_alpha8), IM_COL32(0,255,0,style_alpha8), IM_COL32(0,255,255,style_alpha8), IM_COL32(0,0,255,style_alpha8), IM_COL32(255,0,255,style_alpha8), IM_COL32(255,0,0,style_alpha8) };
        ImVec4 hue_color_f(1, 1, 1, style.Alpha);
        ColorConvertHSVtoRGB(H, 1, 1, hue_color_f.x, hue_color_f.y, hue_color_f.z);
        ImU32 hue_color32 = ColorConvertFloat4ToU32(hue_color_f);
        ImU32 user_col32_striped_of_alpha = ColorConvertFloat4ToU32(ImVec4(R, G, B, style.Alpha));
        static std::map<ImGuiID, picker_state> anim;
        picker_state& state = anim[ImGui::GetID(label)];
        ImVec2 sv_cursor_pos;
        draw_list->AddRectFilledMultiColorExOne(picker_pos, picker_pos + ImVec2(sv_picker_size, sv_picker_size), col_white, hue_color32, hue_color32, col_white);
        draw_list->AddRectFilledMultiColorExOne(picker_pos - ImVec2(1, 1), picker_pos + ImVec2(sv_picker_size + 1, sv_picker_size + 1), 0, 0, col_black, col_black);
        sv_cursor_pos.x = ImClamp(IM_ROUND(picker_pos.x + ImSaturate(S) * sv_picker_size), picker_pos.x + 2, picker_pos.x + sv_picker_size - 2);
        sv_cursor_pos.y = ImClamp(IM_ROUND(picker_pos.y + ImSaturate(1 - V) * sv_picker_size), picker_pos.y + 2, picker_pos.y + sv_picker_size - 2);
        for (int i = 0; i < 6; ++i) draw_list->AddRectFilledMultiColorExOne(ImVec2(bar0_pos_x, picker_pos.y + i * (sv_picker_size / 6) - (i == 5 ? 1 : 0)), ImVec2(bar0_pos_x + bars_width, picker_pos.y + (i + 1) * (sv_picker_size / 6) + (i == 0 ? 1 : 0)), col_hues[i], col_hues[i], col_hues[i + 1], col_hues[i + 1]);
        float bar0_line_y = IM_ROUND(picker_pos.y + H * sv_picker_size);
        bar0_line_y = ImClamp(bar0_line_y, picker_pos.y + 3.f, picker_pos.y + (sv_picker_size - 13));
        state.hue_bar = ImLerp(state.hue_bar, bar0_line_y + 5, g.IO.DeltaTime * 24.f);
        draw_list->AddCircleFilled(ImVec2(bar0_pos_x + 7.5f, state.hue_bar), 4.5f, col_black, 100.f);
        float sv_cursor_rad = value_changed_sv ? 10.0f : 6.0f;
        int sv_cursor_segments = draw_list->_CalcCircleAutoSegmentCount(sv_cursor_rad);
        state.circle_move = ImLerp(state.circle_move, sv_cursor_pos, g.IO.DeltaTime * 10.f);
        state.circle = ImLerp(state.circle, value_changed_sv ? 6.0f : 4.0f, g.IO.DeltaTime * 24.f);
        draw_list->AddCircle(state.circle_move, state.circle, col_white, sv_cursor_segments, 2.f);
        if (alpha_bar) {
            float alpha = ImSaturate(col[3]);
            ImRect bar1_bb(bar1_pos_x, picker_pos.y, bar1_pos_x + bars_width, picker_pos.y + sv_picker_size);
            draw_list->AddRectFilledMultiColorExOne(bar1_bb.Min, bar1_bb.Max, user_col32_striped_of_alpha, user_col32_striped_of_alpha, user_col32_striped_of_alpha & ~IM_COL32_A_MASK, user_col32_striped_of_alpha & ~IM_COL32_A_MASK);
            float bar1_line_y = IM_ROUND(picker_pos.y + (1.0f - alpha) * sv_picker_size);
            bar1_line_y = ImClamp(bar1_line_y, picker_pos.y + 3.f, picker_pos.y + (sv_picker_size - 13));
            state.alpha_bar = ImLerp(state.alpha_bar, bar1_line_y + 5, g.IO.DeltaTime * 24.f);
            draw_list->AddCircleFilled(ImVec2(bar1_pos_x + 7.5f, state.alpha_bar), 4.5f, col_black, 100.f);
        }
        EndGroup();
        if (value_changed && memcmp(backup_initial_col, col, components * sizeof(float)) == 0) value_changed = false;
        if (value_changed) MarkItemEdited(g.LastItemData.ID);
        PopID();
        return value_changed;
    }

    struct edit_state {
        ImVec4 text;
        float alpha = 0.f;
        bool hovered, active;
    };

    bool ColorEdit4(const char* label, const char* description, float col[4], ImGuiColorEditFlags flags) {
        ImGuiWindow* window = GetCurrentWindow();
        if (window->SkipItems) return false;
        ImGuiContext& g = *GImGui;
        const ImGuiStyle& style = g.Style;
        const float square_sz = 18.f;
        const float w_full = CalcItemWidth();
        const float w_button = (flags & ImGuiColorEditFlags_NoSmallPreview) ? 0.0f : square_sz;
        const float w_inputs = w_full - w_button;
        const char* label_display_end = FindRenderedTextEnd(label);
        g.NextItemData.ClearFlags();
        char buf[64];
        BeginGroup();
        PushID(label);
        const bool set_current_color_edit_id = (g.ColorEditCurrentID == 0);
        if (set_current_color_edit_id) g.ColorEditCurrentID = window->IDStack.back();
        const ImGuiColorEditFlags flags_untouched = flags;
        if (flags & ImGuiColorEditFlags_NoInputs) flags = (flags & (~ImGuiColorEditFlags_DisplayMask_)) | ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_NoOptions;
        if (!(flags & ImGuiColorEditFlags_NoOptions)) ColorEditOptionsPopup(col, flags);
        if (!(flags & ImGuiColorEditFlags_DisplayMask_))
            flags |= (g.ColorEditOptions & ImGuiColorEditFlags_DisplayMask_);
        if (!(flags & ImGuiColorEditFlags_DataTypeMask_))
            flags |= (g.ColorEditOptions & ImGuiColorEditFlags_DataTypeMask_);
        if (!(flags & ImGuiColorEditFlags_PickerMask_))
            flags |= (g.ColorEditOptions & ImGuiColorEditFlags_PickerMask_);
        if (!(flags & ImGuiColorEditFlags_InputMask_))
            flags |= (g.ColorEditOptions & ImGuiColorEditFlags_InputMask_);
        flags |= (g.ColorEditOptions & ~(ImGuiColorEditFlags_DisplayMask_ | ImGuiColorEditFlags_DataTypeMask_ | ImGuiColorEditFlags_PickerMask_ | ImGuiColorEditFlags_InputMask_));
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_DisplayMask_));
        IM_ASSERT(ImIsPowerOfTwo(flags & ImGuiColorEditFlags_InputMask_));
        const bool alpha = (flags & ImGuiColorEditFlags_NoAlpha) == 0;
        const bool hdr = (flags & ImGuiColorEditFlags_HDR) != 0;
        const int components = alpha ? 4 : 3;
        float f[4] = { col[0], col[1], col[2], alpha ? col[3] : 1.0f };
        if ((flags & ImGuiColorEditFlags_InputHSV) && (flags & ImGuiColorEditFlags_DisplayRGB)) {
            ColorConvertHSVtoRGB(f[0], f[1], f[2], f[0], f[1], f[2]);
        } else if ((flags & ImGuiColorEditFlags_InputRGB) && (flags & ImGuiColorEditFlags_DisplayHSV)) {
            ColorConvertRGBtoHSV(f[0], f[1], f[2], f[0], f[1], f[2]);
            ColorEditRestoreHS(col, &f[0], &f[1], &f[2]);
        }
        int i[4] = { IM_F32_TO_INT8_UNBOUND(f[0]), IM_F32_TO_INT8_UNBOUND(f[1]), IM_F32_TO_INT8_UNBOUND(f[2]), IM_F32_TO_INT8_UNBOUND(f[3]) };
        bool value_changed = false;
        bool value_changed_as_float = false;
        const ImVec2 pos = window->DC.CursorPos;
        const float inputs_offset_x = (style.ColorButtonPosition == ImGuiDir_Left) ? w_button : 0.0f;
        window->DC.CursorPos.x = pos.x + inputs_offset_x;
        if ((flags & (ImGuiColorEditFlags_DisplayRGB | ImGuiColorEditFlags_DisplayHSV)) != 0 && (flags & ImGuiColorEditFlags_NoInputs) == 0) {
            const float w_item_one = ImMax(1.0f, IM_FLOOR((w_inputs - (style.ItemInnerSpacing.x) * (components - 1)) / (float)components));
            const float w_item_last = ImMax(1.0f, IM_FLOOR(w_inputs - (w_item_one + style.ItemInnerSpacing.x) * (components - 1)));
            const bool hide_prefix = (w_item_one <= CalcTextSize((flags & ImGuiColorEditFlags_Float) ? "M:0.000" : "M:000").x);
            static const char* ids[4] = { "##X", "##Y", "##Z", "##W" };
            static const char* fmt_table_int[3][4] = {
                {   "%3d",   "%3d",   "%3d",   "%3d" },
                { "R:%3d", "G:%3d", "B:%3d", "A:%3d" },
                { "H:%3d", "S:%3d", "V:%3d", "A:%3d" }
            };
            static const char* fmt_table_float[3][4] = {
                {   "%0.3f",   "%0.3f",   "%0.3f",   "%0.3f" },
                { "R:%0.3f", "G:%0.3f", "B:%0.3f", "A:%0.3f" },
                { "H:%0.3f", "S:%0.3f", "V:%0.3f", "A:%0.3f" }
            };
            const int fmt_idx = hide_prefix ? 0 : (flags & ImGuiColorEditFlags_DisplayHSV) ? 2 : 1;
            for (int n = 0; n < components; n++) {
                if (n > 0) SameLine(0, style.ItemInnerSpacing.x);
                SetNextItemWidth((n + 1 < components) ? w_item_one : w_item_last);
                if (flags & ImGuiColorEditFlags_Float) {
                    value_changed |= DragFloat(ids[n], &f[n], 1.0f / 255.0f, 0.0f, hdr ? 0.0f : 1.0f, fmt_table_float[fmt_idx][n]);
                    value_changed_as_float |= value_changed;
                } else {
                    value_changed |= DragInt(ids[n], &i[n], 1.0f, 0, hdr ? 0 : 255, fmt_table_int[fmt_idx][n]);
                }
                if (!(flags & ImGuiColorEditFlags_NoOptions)) OpenPopupOnItemClick("context", ImGuiPopupFlags_MouseButtonRight);
            }
        }
        static std::map<ImGuiID, edit_state> anim;
        edit_state& state = anim[ImGui::GetID(label)];
        if (!(flags & ImGuiColorEditFlags_NoSmallPreview)) {
            const float button_offset_x = ((flags & ImGuiColorEditFlags_NoInputs) || (style.ColorButtonPosition == ImGuiDir_Left)) ? 0.0f : w_inputs + style.ItemInnerSpacing.x;
            window->DC.CursorPos = ImVec2(pos.x + button_offset_x, pos.y);
            const ImVec4 col_v4(col[0], col[1], col[2], alpha ? col[3] : 1.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameBorderSize, 0.0f);
            ImGui::PushStyleVar(ImGuiStyleVar_FrameRounding, 4.0f);
            if (ColorButton("##ColorButton", col_v4, flags, ImVec2(50, 25))) {
                if (!(flags & ImGuiColorEditFlags_NoPicker)) {
                    g.ColorPickerRef = col_v4;
                    OpenPopup("picker");
                    SetNextWindowPos(g.LastItemData.Rect.GetBL() + ImVec2(0.0f, style.ItemSpacing.y));
                }
            }
            ImGui::PopStyleVar(2);
            if (!(flags & ImGuiColorEditFlags_NoOptions)) OpenPopupOnItemClick("context", ImGuiPopupFlags_MouseButtonRight);
            if (ItemHoverable(g.LastItemData.Rect, g.LastItemData.ID, NULL) && g.IO.MouseClicked[0] || state.active && !state.hovered && g.IO.MouseClicked[0])
                state.active = !state.active;
            PushStyleColor(ImGuiCol_WindowBg, GetColorU32(Colors::background));
            PushStyleColor(ImGuiCol_Border, GetColorU32(Colors::background_widget));
            PushStyleVar(ImGuiStyleVar_WindowRounding, Colors::rounding);
            PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(15, 15));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.f);
            if (state.active) {
                SetNextWindowPos(g.LastItemData.Rect.GetTR() + ImVec2(-45, -5));
                Begin("picker", NULL, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize);
                {
                    state.hovered = IsWindowHovered();
                    ImVec4 col_v4(col[0], col[1], col[2], (flags & ImGuiColorEditFlags_NoAlpha) ? 1.0f : col[3]);
                    if (alpha)
                        ImFormatString(buf, IM_ARRAYSIZE(buf), "#%02X%02X%02X%02X", ImClamp(i[0], 0, 255), ImClamp(i[1], 0, 255), ImClamp(i[2], 0, 255), ImClamp(i[3], 0, 255));
                    else
                        ImFormatString(buf, IM_ARRAYSIZE(buf), "#%02X%02X%02X", ImClamp(i[0], 0, 255), ImClamp(i[1], 0, 255), ImClamp(i[2], 0, 255));
                    GetWindowDrawList()->AddText(ImGui::GetFont(), 26.f, GetCursorScreenPos() - ImVec2(0, 2), GetColorU32(Colors::text::text_active), (label != label_display_end && !(flags & ImGuiColorEditFlags_NoLabel)) ? label : "Color picker");
                    ImGui::SetCursorPosY(GetCursorPosY() + 34);
                    ImGuiColorEditFlags picker_flags_to_forward = ImGuiColorEditFlags_DataTypeMask_ | ImGuiColorEditFlags_PickerMask_ | ImGuiColorEditFlags_InputMask_ | ImGuiColorEditFlags_HDR | ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_AlphaBar;
                    ImGuiColorEditFlags picker_flags = (flags_untouched & picker_flags_to_forward) | ImGuiColorEditFlags_DisplayMask_ | ImGuiColorEditFlags_NoLabel | ImGuiColorEditFlags_AlphaPreviewHalf;
                    SetNextItemWidth(square_sz * 11.5f);
                    value_changed |= ColorPicker4("##picker", col, picker_flags, &g.ColorPickerRef.x);
                    if (InputTextEx("v", "HEX COLOR", buf, IM_ARRAYSIZE(buf), ImVec2(!(flags & ImGuiColorEditFlags_NoAlpha) ? 128 : 118, 35), ImGuiInputTextFlags_CharsHexadecimal | ImGuiInputTextFlags_CharsUppercase)) {
                        value_changed = true;
                        char* p = buf;
                        while (*p == '#' || ImCharIsBlankA(*p)) p++;
                        i[0] = i[1] = i[2] = 0;
                        i[3] = 0xFF;
                        int r;
                        if (alpha)
                            r = sscanf(p, "%02X%02X%02X%02X", (unsigned int*)&i[0], (unsigned int*)&i[1], (unsigned int*)&i[2], (unsigned int*)&i[3]);
                        else
                            r = sscanf(p, "%02X%02X%02X", (unsigned int*)&i[0], (unsigned int*)&i[1], (unsigned int*)&i[2]);
                        IM_UNUSED(r);
                    }
                    ImGui::SameLine(0, 3);
                    static std::vector<float> color_x, color_y, color_z, color_a;
                    static bool add_status = true;
                    if (icon_box("+", ImVec2(35, 35), GetColorU32(Colors::background_widget), GetColorU32(Colors::accent), GetColorU32ExOne(Colors::accent, 0.f))) {
                        color_x.push_back(col[0]);
                        color_y.push_back(col[1]);
                        color_z.push_back(col[2]);
                        color_a.push_back(col[3]);
                    }
                    ImGui::SameLine(0, 3);
                    if (icon_box("-", ImVec2(35, 35), GetColorU32(Colors::background_widget), GetColorU32(Colors::accent), GetColorU32ExOne(Colors::accent, 0.f))) {
                        if (color_x.size() > 0) {
                            color_x.pop_back();
                            color_y.pop_back();
                            color_z.pop_back();
                            color_a.pop_back();
                        }
                    }
                    if (IsItemHovered() && GetIO().MouseClicked[1]) add_status = !add_status;
                    for (int i = 0; i < (int)color_x.size(); i++) {
                        std::string name_box = std::to_string(i);
                        if (color_button(name_box.c_str(), ImVec2(17, 17), ImColor(color_x[i], color_y[i], color_z[i], color_a[i]))) {
                            col[0] = color_x[i], col[1] = color_y[i], col[2] = color_z[i], col[3] = color_a[i];
                        };
                        if ((i + 1) % 7 != 0) ImGui::SameLine(0, 18.f);
                    }
                }
                End();
            }
        }
        PopStyleColor(2);
        PopStyleVar(3);
        state.text = ImLerp(state.text, state.active ? Colors::text::text_active : Colors::text::text, g.IO.DeltaTime * 6.f);
        if (label != label_display_end && !(flags & ImGuiColorEditFlags_NoLabel)) {
            SameLine(0.0f, style.ItemInnerSpacing.x);
            window->DC.CursorPos.x = pos.x - w_button + ((flags & ImGuiColorEditFlags_NoInputs) ? w_button : w_full);
            GetWindowDrawList()->AddText(ImGui::GetFont(), 14.f, pos + ImVec2(10, 0), GetColorU32(Colors::text::text), description);
            GetWindowDrawList()->AddText(ImGui::GetFont(), 14.f, pos + ImVec2(10, 18), GetColorU32(Colors::text::text_active), label);
        }
        PopID();
        EndGroup();
        return value_changed;
    }
}