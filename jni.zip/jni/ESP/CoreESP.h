#pragma once
#include "../Include/对接.h" // 确保这里包含了你的 ghost_api.h
#include "Offsets.h"
#include "MathUtils.h"
#include "../ImGui/imgui.h"

// ==========================================================
// [大牛核心适配器] 将内核 C 接口包装为 C++ 泛型模板
// ==========================================================
template <typename T>
inline T GhostRead(uint32_t pid, uintptr_t address) {
    T buffer{};
    if (address != 0 && pid != 0) {
        // 调用 ghost_api.h 中的物理内存穿透读取接口
        ghost_core_read_mem(pid, address, &buffer, sizeof(T));
    }
    return buffer;
}

class CoreESP {
public:
    // 特别注意：第一个参数是 PID，用来告诉内核驱动读哪个进程
    static void Draw(uint32_t target_pid, uintptr_t libbase, int w, int h) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        
        if (libbase == 0 || target_pid == 0) return;

        // 1. 读取摄像机矩阵
        Matrix4x4 vMatrix = GhostRead<Matrix4x4>(target_pid, libbase + Offsets::CameraManager_Static);
        
        // 2. 获取 KHPlayerManager 单例
        uintptr_t mgr = GhostRead<uintptr_t>(target_pid, libbase + Offsets::KHPlayerManager_Static);
        if (!mgr) return;
        
        // 3. 解析玩家列表 List<KHPlayerActor>
        uintptr_t pList = GhostRead<uintptr_t>(target_pid, mgr + Offsets::m_playerList);
        int size = GhostRead<int>(target_pid, pList + Offsets::ListSize);
        uintptr_t items = GhostRead<uintptr_t>(target_pid, pList + Offsets::ListItems);
        
        // 安全保护：防止读到非法大内存导致循环卡死
        if (size > 100 || size < 0) return;

        for (int i = 0; i < size; i++) {
            // 读取数组中的 Actor 指针
            uintptr_t actor = GhostRead<uintptr_t>(target_pid, items + Offsets::ArrayData + (i * 8));
            if (!actor) continue;

            // 4. 获取 3D 坐标并转换
            Vector3 pos = GhostRead<Vector3>(target_pid, actor + Offsets::ActorPosition);
            Vector2 screenPos;
            
            if (MathUtils::WorldToScreen(pos, vMatrix, w, h, screenPos)) {
                
                // 5. 读取技能 CD 链条 (以技能 C 为例)
                uintptr_t skillC = GhostRead<uintptr_t>(target_pid, actor + Offsets::dynamicSkillC);
                if (!skillC) continue;

                uintptr_t group = GhostRead<uintptr_t>(target_pid, skillC + Offsets::itemSkillGroup);
                uintptr_t infoList = GhostRead<uintptr_t>(target_pid, group + Offsets::skillInfos);
                uintptr_t infoItems = GhostRead<uintptr_t>(target_pid, infoList + Offsets::ListItems);
                uintptr_t firstInfo = GhostRead<uintptr_t>(target_pid, infoItems + Offsets::ArrayData);
                
                // 读取当前剩余 CD (帧数 Int32)
                int cdFrames = GhostRead<int>(target_pid, firstInfo + Offsets::leftCd);
                
                // 绘制逻辑
                char buf[64];
                if (cdFrames > 0) {
                    // 换算秒数 (火影手游逻辑帧通常为 60)
                    sprintf(buf, "Skill C: %.1fs", cdFrames / 60.0f);
                    drawList->AddText({screenPos.x, screenPos.y - 40}, ImColor(255, 50, 50, 255), buf);
                } else {
                    drawList->AddText({screenPos.x, screenPos.y - 40}, ImColor(50, 255, 50, 255), "READY");
                }
            }
        }
    }
};
