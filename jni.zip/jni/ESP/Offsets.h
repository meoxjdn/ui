#pragma once

namespace Offsets {
    // ---- 静态基址 (需要你根据最后一次 IDA 确定的 RVA 填入) ----
    // 示例: 对应你之前看到的 off_BB11D48 等基址
    static uintptr_t KHPlayerManager_Static = 0x0; // 填入 PlayerManager 的真实 RVA
    static uintptr_t CameraManager_Static   = 0x0; // 填入相机矩阵的真实 RVA

    // ---- IL2CPP 基础偏移 ----
    static uintptr_t ListItems = 0x10; 
    static uintptr_t ListSize  = 0x18; 
    static uintptr_t ArrayData = 0x20; 

    // ---- 业务偏移 ----
    static uintptr_t m_playerList  = 0x70;   // KHPlayerManager -> m_playerList
    static uintptr_t ActorPosition = 0x123;  // 填入你最终确定的 Vector3 偏移

    // 技能链条
    static uintptr_t dynamicSkillC = 0x5d8;  // ActorModel -> ItemSkill
    static uintptr_t itemSkillGroup = 0x30;  // ItemSkill -> SkillGroup
    static uintptr_t skillInfos    = 0x50;   // SkillGroup -> List<SkillInfo>
    static uintptr_t leftCd        = 0x14;   // SkillInfo -> leftCd (Int32帧数)
}
