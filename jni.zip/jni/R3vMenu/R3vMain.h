#ifndef R3V_MAIN_H
#define R3V_MAIN_H

#include "Custom.h"
#include "窗口变量.h"

// ==========================================
// [大牛添加] 引入内核对接与 ESP 核心组件
// ==========================================
#include "../Include/对接.h"
#include "../ESP/CoreESP.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

// ==========================================
// [大牛添加] 获取本进程内 libil2cpp.so 的真实基址
// ==========================================
static uintptr_t get_module_base(const char* module_name) {
    FILE *fp = fopen("/proc/self/maps", "r");
    if (!fp) return 0;
    
    char line[512];
    uintptr_t base = 0;
    while (fgets(line, sizeof(line), fp)) {
        if (strstr(line, module_name)) {
            char *dash = strchr(line, '-');
            if (dash) {
                *dash = '\0';
                base = strtoul(line, NULL, 16);
                break;
            }
        }
    }
    fclose(fp);
    return base;
}

// ==========================================
// 全局运行变量
// ==========================================
static uintptr_t g_LibBase = 0;          // 缓存 libil2cpp.so 基址
static bool g_EnableSkillCD = false;     // 控制技能 CD 透视的开关

static void GetContentSize(float& width, float& height) {
    width = ImGui::GetContentRegionAvail().x;
    height = ImGui::GetContentRegionAvail().y;
}

static const char* GetPageTitle(int tab) {
    switch (tab) {
        case 0: return "RAGE - AIMBOT";
        case 1: return "RAGE - ANTI AIM";
        case 2: return "VISUALS - ESP";
        case 3: return "VISUALS - CHAMS";
        case 4: return "VISUALS - WORLD";
        case 5: return "MISC - MEMORY";
        case 6: return "MISC - SKINCHANGER";
        case 7: return "OTHER - SETTINGS";
        default: return "UNKNOWN - UNKNOWN";
    }
}

static void DrawPageTitle(int selected_tab) {
    const char* title = GetPageTitle(selected_tab);
    float font_size = 28.0f;
    ImVec2 text_size = ImGui::CalcTextSize(title);
    float height = text_size.y + 4.0f;
    ImVec2 pos = ImGui::GetCursorScreenPos();
    Custom::GlowText(ImGui::GetFont(), font_size, title, pos, ImGui::GetColorU32(Custom::Colors::accent));
    ImGui::Dummy(ImVec2(0, height));
}

void R3vMain() {
    // ==========================================
    // [大牛添加] 只在初始化时获取一次基址，拒绝卡顿
    // ==========================================
    if (g_LibBase == 0) {
        g_LibBase = get_module_base("libil2cpp.so");
    }

    ImGui::SetNextWindowSize(ImVec2(770, 465));
    ImGui::PushStyleColor(ImGuiCol_WindowBg, IM_COL32(15, 17, 16, 255));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 28.0f);
    ImGui::PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar;
    
    if (ImGui::Begin("R3v-CustomTest", nullptr, flags)) {
        static int selected_tab = 0;
        if (ImGui::BeginChild("LeftTabs", ImVec2(160, 0), false)) {
            ImGui::Text("RAGE");
            if (Custom::Tab("AIMBOT", selected_tab == 0)) selected_tab = 0;
            if (Custom::Tab("ANTI AIM", selected_tab == 1)) selected_tab = 1;
            ImGui::Text("VISUALS");
            if (Custom::Tab("ESP", selected_tab == 2)) selected_tab = 2;
            if (Custom::Tab("CHAMS", selected_tab == 3)) selected_tab = 3;
            if (Custom::Tab("WORLD", selected_tab == 4)) selected_tab = 4;
            ImGui::Text("MISC");
            if (Custom::Tab("MEMORY", selected_tab == 5)) selected_tab = 5;
            if (Custom::Tab("SKINCHANGER", selected_tab == 6)) selected_tab = 6;
            ImGui::Text("OTHER");
            if (Custom::Tab("SETTINGS", selected_tab == 7)) selected_tab = 7;
            ImGui::EndChild();
        }
        ImGui::SameLine();
        if (ImGui::BeginChild("RightContent", ImVec2(0, 0), false)) {
            DrawPageTitle(selected_tab);
            float content_width, content_height;
            GetContentSize(content_width, content_height);
            switch (selected_tab) {
                case 0: {
                    float child_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Main Settings", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Weapon Settings", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 1: {
                    float child_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Anti Aim", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Advanced AA", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 2: {
                    float left_width = (content_width - 12.0f) / 2.0f;
                    float right_width = left_width;
                    if (Custom::begin_child("ESP", ImVec2(left_width, 0), false, 0)) {
                        Custom::Switch("Enable", &r3vfunction.espfun.Enable);
                        Custom::Switch("Box", &r3vfunction.espfun.Box);
                        Custom::Switch("Health", &r3vfunction.espfun.Health);
                        Custom::Switch("Armor", &r3vfunction.espfun.Armor);
                        Custom::Switch("Skeleton", &r3vfunction.espfun.Skeleton);
                        Custom::Switch("Nickname", &r3vfunction.espfun.Nickname);
                        Custom::Switch("Weapon", &r3vfunction.espfun.Weapon);
                        
                        // ==========================================
                        // [大牛添加] 在你的 ESP 列表里加上我们的专属开关
                        // ==========================================
                        ImGui::Spacing();
                        Custom::Switch("Skill CD Tracker", &g_EnableSkillCD);

                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (ImGui::BeginChild("RightColumn", ImVec2(right_width, 0), false)) {
                        if (Custom::begin_child("Test01", ImVec2(0, 199), false, 0)) {
                            Custom::EndChild();
                        }
                        if (Custom::begin_child("Test02", ImVec2(0, 197), false, 0)) {
                            Custom::EndChild();
                        }
                    }
                    ImGui::EndChild();
                } break;

                case 3: {
                    float child_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Chams Type", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Color Settings", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 4: {
                    float child_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("World", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Camera", ImVec2(child_width, 0), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 5: {
                    float cell_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Movement", ImVec2(cell_width, 199), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Combat", ImVec2(cell_width, 199), false, 0)) {
                        Custom::EndChild();
                    }
                    if (Custom::begin_child("Visuals", ImVec2(cell_width, 197), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Other", ImVec2(cell_width, 197), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 6: {
                    float cell_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Weapons", ImVec2(cell_width, 199), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Gloves", ImVec2(cell_width, 199), false, 0)) {
                        Custom::EndChild();
                    }
                    if (Custom::begin_child("Quality", ImVec2(cell_width, 197), false, 0)) {
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Actions", ImVec2(cell_width, 197), false, 0)) {
                        Custom::EndChild();
                    }
                } break;

                case 7: {
                    float child_width = (content_width - 12.0f) / 2.0f;
                    if (Custom::begin_child("Settings", ImVec2(child_width, 0), false, 0)) {
                        float accent_color[4] = {
                            Custom::Colors::accent.x,
                            Custom::Colors::accent.y,
                            Custom::Colors::accent.z,
                            Custom::Colors::accent.w
                        };
                        if (Custom::ColorEdit4("##AccentPicker", "Accent Color", accent_color, ImGuiColorEditFlags_NoAlpha | ImGuiColorEditFlags_NoTooltip | ImGuiColorEditFlags_NoInputs)) {
                            Custom::Colors::accent.x = accent_color[0];
                            Custom::Colors::accent.y = accent_color[1];
                            Custom::Colors::accent.z = accent_color[2];
                            Custom::Colors::accent.w = accent_color[3];
                        }
                        Custom::EndChild();
                    }
                    ImGui::SameLine(0.0f, 12.0f);
                    if (Custom::begin_child("Config", ImVec2(child_width, 0), false, 0)) {
                        if (Custom::Button("Save Config")) {
                            Custom::g_NotificationSystem.AddNotification("Config saved! TestTestTestTest", 3000, 0);
                        }
                        if (Custom::Button("Load Config")) {
                            Custom::g_NotificationSystem.AddNotification("Config loaded! TestTestTestTest", 3000, 1);
                        }
                        Custom::EndChild();
                    }
                } break;
            }
            ImGui::EndChild();
        }
    }
    ImGui::End();
    ImGui::PopStyleVar(2);
    ImGui::PopStyleColor();

    // ==========================================
    // [大牛添加] ESP 渲染接管层
    // 注意：放在 ImGui::End() 之后，确保它是画在最顶层且不受菜单窗口折叠的影响
    // ==========================================
    if (g_EnableSkillCD && g_LibBase != 0) {
        // 动态获取当前设备真实的屏幕分辨率，确保 W2S 投影精准
        ImVec2 displaySize = ImGui::GetIO().DisplaySize;
        
        // 呼叫咱们逆向写好的底层 ESP 绘制
        // 【关键点】这里传入了 getpid() 提供给你的内核通信模块
        CoreESP::Draw(getpid(), g_LibBase, (int)displaySize.x, (int)displaySize.y);
    }
}

#endif
