/*
 * =====================================================================================
 * Filename:  ghost_api.h
 * Description:  Ghost Core V27.1 Industrial Grade Integration SDK
 * Architecture: AArch64 (ARMv8-A + PAC Aware)
 * Status:       Production Ready (Polymorphic Armor & PTE Piercing Memory Reader)
 * =====================================================================================
 */

#ifndef GHOST_API_H
#define GHOST_API_H

#include <stdint.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include <sys/socket.h>
#include <linux/netlink.h>

/* ==========================================================
 * 隧道基础参数与魔术指令 (Protocol & Magic Commands)
 * ========================================================== */
#define GHOST_NETLINK_ID     31 
#define GHOST_CMD_INSTALL    0x1001
#define GHOST_CMD_CLEANUP    0x1002
#define GHOST_CMD_MEM_READ   0x1003
#define GHOST_CMD_MEM_ACK    0x1004

/* ==========================================================
 * 内存布局严格对齐 (ABI Memory Layout)
 * 必须与 Kernel 侧精确保持一致，禁止修改字段顺序
 * ========================================================== */
#pragma pack(push, 8)

/* 战术载荷明文体 (全量特征保留) */
struct ghost_hbp_req {
    int      tid;
    uint64_t base_addr;

    uint64_t off_border;
    uint64_t off_pause_win;
    uint64_t off_pause_jmp; 
    uint64_t off_damage;
    uint64_t off_fov;
    uint64_t off_kill;

    int      maxhp_on;
    uint64_t fov_val;      
    int      fov_reg;      
    int      fov_is_ptr;   
    int      fov_pc_step;  

    int      fov_on;
    int      border_on;
    int      skip_on;
    int      damage_on;
};

/* 动态多态加壳层 (Polymorphic Armor Wrapper) */
struct ghost_hbp_pkt {
    uint32_t seed;
    struct ghost_hbp_req payload;
};

/* 物理内存穿透请求体 */
struct ghost_mem_req {
    uint32_t pid;
    uint64_t addr;
    uint32_t size;
};

#pragma pack(pop)

/* Netlink 安装/清理请求封包 */
struct ghost_nl_msg_install {
    struct nlmsghdr nlh;
    struct ghost_hbp_pkt pkt;
};

/* Netlink 内存读取交互封包 */
struct ghost_nl_msg_mem {
    struct nlmsghdr nlh;
    struct ghost_mem_req req;
};

/* ==========================================================
 * 核心驱动接口 (Core Driver APIs)
 * ========================================================== */

/**
 * [内部计算] 生成高随机性多态 Seed
 */
static inline uint32_t ghost_internal_generate_seed(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint32_t)(ts.tv_nsec ^ getpid());
}

/**
 * [下行链路] 下发控制指令或多态注入载荷
 * @param cmd 指令宏 (GHOST_CMD_INSTALL 或 GHOST_CMD_CLEANUP)
 * @param req 战术载荷配置。若发送 CLEANUP 指令可传 NULL。
 * @return 1 投递成功, 0 投递失败
 */
static inline int ghost_core_invoke(uint16_t cmd, const struct ghost_hbp_req *req) {
    int sock_fd = socket(PF_NETLINK, SOCK_RAW, GHOST_NETLINK_ID);
    if (sock_fd < 0) {
        return 0;
    }
    
    struct sockaddr_nl dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.nl_family = AF_NETLINK;
    dest_addr.nl_pid = 0;     /* 路由至 Kernel VMM */
    dest_addr.nl_groups = 0;  /* 独立单播 */
    
    struct ghost_nl_msg_install msg;
    memset(&msg, 0, sizeof(msg));
    
    size_t pkt_len = (req != NULL) ? sizeof(struct ghost_hbp_pkt) : 0;
    
    msg.nlh.nlmsg_len = NLMSG_LENGTH(pkt_len);
    msg.nlh.nlmsg_pid = getpid();
    msg.nlh.nlmsg_flags = NLM_F_REQUEST;
    msg.nlh.nlmsg_type = cmd; 
    
    /* 触发多态变异引擎，瘫痪服务端 YARA 静态特征扫盘 */
    if (req) {
        int i;
        msg.pkt.seed = ghost_internal_generate_seed();
        
        const uint8_t *raw_req = (const uint8_t *)req;
        uint8_t *enc_payload = (uint8_t *)&msg.pkt.payload;
        uint8_t *seed_bytes = (uint8_t *)&msg.pkt.seed;
        
        for (i = 0; i < sizeof(struct ghost_hbp_req); i++) {
            enc_payload[i] = raw_req[i] ^ seed_bytes[i % 4];
        }
    }
    
    struct iovec iov = {
        .iov_base = (void *)&msg.nlh,
        .iov_len = msg.nlh.nlmsg_len
    };
    
    struct msghdr net_msg = {
        .msg_name = (void *)&dest_addr,
        .msg_namelen = sizeof(dest_addr),
        .msg_iov = &iov,
        .msg_iovlen = 1
    };
    
    int ret = sendmsg(sock_fd, &net_msg, 0);
    close(sock_fd);
    
    return (ret > 0) ? 1 : 0;
}

/**
 * [双向链路] 跨进程物理页表漫游读取 (PTE Piercing)
 * @param pid 目标进程 PID
 * @param addr 目标虚拟内存地址 (UADDR)
 * @param buf 接收缓冲区指针
 * @param size 期望读取的字节数 (单次极限 4096 字节)
 * @return 实际成功读取的字节数, 0 表示失败或越界
 */
static inline int ghost_core_read_mem(uint32_t pid, uint64_t addr, void *buf, size_t size) {
    if (!buf || size == 0) return 0;
    
    int sock_fd = socket(PF_NETLINK, SOCK_RAW, GHOST_NETLINK_ID);
    if (sock_fd < 0) return 0;
    
    /* 必须绑定本地端口，用于接收内核 ACK 的反向寻址 */
    struct sockaddr_nl src_addr;
    memset(&src_addr, 0, sizeof(src_addr));
    src_addr.nl_family = AF_NETLINK;
    src_addr.nl_pid = getpid();
    if (bind(sock_fd, (struct sockaddr*)&src_addr, sizeof(src_addr)) < 0) {
        close(sock_fd);
        return 0;
    }
    
    struct sockaddr_nl dest_addr;
    memset(&dest_addr, 0, sizeof(dest_addr));
    dest_addr.nl_family = AF_NETLINK;
    dest_addr.nl_pid = 0;
    
    struct ghost_nl_msg_mem req_msg;
    memset(&req_msg, 0, sizeof(req_msg));
    
    req_msg.nlh.nlmsg_len = NLMSG_LENGTH(sizeof(struct ghost_mem_req));
    req_msg.nlh.nlmsg_pid = getpid();
    req_msg.nlh.nlmsg_flags = NLM_F_REQUEST;
    req_msg.nlh.nlmsg_type = GHOST_CMD_MEM_READ;
    
    req_msg.req.pid = pid;
    req_msg.req.addr = addr;
    req_msg.req.size = (size > 4096) ? 4096 : size; /* 防溢出断路器 */
    
    struct iovec iov_send = { 
        .iov_base = &req_msg, 
        .iov_len = req_msg.nlh.nlmsg_len 
    };
    
    struct msghdr net_msg_send = {
        .msg_name = &dest_addr, 
        .msg_namelen = sizeof(dest_addr),
        .msg_iov = &iov_send, 
        .msg_iovlen = 1
    };
    
    if (sendmsg(sock_fd, &net_msg_send, 0) < 0) {
        close(sock_fd);
        return 0;
    }
    
    /* 挂起状态机，等待内核 PTE 漫游完成并返回数据 */
    char recv_buf[8192];
    struct iovec iov_recv = { 
        .iov_base = recv_buf, 
        .iov_len = sizeof(recv_buf) 
    };
    
    struct msghdr net_msg_recv = {
        .msg_name = &dest_addr, 
        .msg_namelen = sizeof(dest_addr),
        .msg_iov = &iov_recv, 
        .msg_iovlen = 1
    };
    
    int bytes = recvmsg(sock_fd, &net_msg_recv, 0);
    close(sock_fd);
    
    if (bytes > 0) {
        struct nlmsghdr *reply_nlh = (struct nlmsghdr *)recv_buf;
        if (reply_nlh->nlmsg_type == GHOST_CMD_MEM_ACK) {
            struct ghost_mem_req *reply_req = (struct ghost_mem_req *)NLMSG_DATA(reply_nlh);
            if (reply_req->size > 0 && reply_req->size <= size) {
                void *data_ptr = (void *)(reply_req + 1);
                memcpy(buf, data_ptr, reply_req->size);
                return reply_req->size;
            }
        }
    }
    
    return 0;
}

#endif /* GHOST_API_H */
