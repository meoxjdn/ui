#include <cstring>
#include <cstdlib>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <ftw.h>
#include <ctime>
#include <algorithm>

typedef unsigned long DWORD;
static uintptr_t libBase;
bool libLoaded = false;

DWORD findLibrary(const char *library) {
    char filename[0xFF] = {0};
    char buffer[1024] = {0};
    FILE *fp = NULL;
    DWORD address = 0;
    sprintf(filename, "/proc/self/maps");
    fp = fopen(filename, "rt");
    if (fp == NULL) {
        goto done;
    }
    while (fgets(buffer, sizeof(buffer), fp)) {
        if (strstr(buffer, library)) {
            address = (DWORD)strtoul(buffer, NULL, 16);
            goto done;
        }
    }
done:
    if (fp) {
        fclose(fp);
    }
    return address;
}

DWORD getAbsoluteAddress(const char *libraryName, DWORD relativeAddr) {
    libBase = findLibrary(libraryName);
    if (libBase == 0) {
        return 0;
    }
    return (reinterpret_cast<DWORD>(libBase + relativeAddr));
}

bool isLibraryLoaded(const char *libraryName) {
    char line[512] = {0};
    FILE *fp = fopen("/proc/self/maps", "rt");
    if (fp != NULL) {
        while (fgets(line, sizeof(line), fp)) {
            if (strstr(line, libraryName)) {
                libLoaded = true;
                fclose(fp);
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}

uintptr_t string2Offset(const char *c) {
    int base = 16;
    static_assert(sizeof(uintptr_t) == sizeof(unsigned long) || sizeof(uintptr_t) == sizeof(unsigned long long), "请添加字符串处理转换以支持此架构。");
    if (sizeof(uintptr_t) == sizeof(unsigned long)) {
        return strtoul(c, nullptr, base);
    }
    return strtoull(c, nullptr, base);
}

std::string GetPackageName() {
    char cmdline[256] = {0};
    FILE* fp = fopen("/proc/self/cmdline", "r");
    if (fp) {
        fgets(cmdline, sizeof(cmdline), fp);
        fclose(fp);
    }
    return std::string(cmdline);
}