struct R3vFunction {
    struct EspFun {
        bool Enable = true;
        bool Box = true;
        bool Health = true;
        bool Armor = true;
        bool Skeleton = true;
        bool Nickname = true;
        bool Weapon = true;
    } espfun;
} r3vfunction;