#include <jni.h>
#include <cmath>
#include <thread>
#include <unistd.h>
#include <pthread.h>
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <dlfcn.h>
#include <sys/system_properties.h>
#include <android/input.h>
#include <android/log.h>
#include <unordered_map>
#include <link.h>
#include "钩子功能.h"

__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, nullptr, hack_thread, nullptr);
    pthread_detach(ptid);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void* reserved) {
    return JNI_VERSION_1_6;
}

/*
           Author: R3v
    Mail: R3v10086@outlook.com
     Date: 2026-03-17 13:30:00
      Copyright (c) 2026 R3v
    SPDX-License-Identifier: MIT
*/