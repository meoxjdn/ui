struct EGLContextInfo {
    int glWidth = 0;
    int glHeight = 0;
    int screenWidth = 0;
    int screenHeight = 0;
    bool dpiInitialized = false;
    void* eglHandle = nullptr;
};

struct TouchPoint {
    int id;
    float x, y;
    bool down;
    int64_t downTime;
};

struct UiTouchController {
    int uiControllerId = -1;
    int64_t uiControllerDownTime = 0;
    bool uiControllerActive = false;
};

static EGLContextInfo g_Egl;
static std::unordered_map<int, TouchPoint> g_TouchPoints;
static int g_TouchCount = 0;
static bool g_Initialized = false;
static bool g_InitDone = false;
static UiTouchController g_UiTouchController;

static bool (*g_ImGuiHitTest)(float x, float y) = nullptr;
static inline void SetImGuiHitTestCallback(bool (*func)(float x, float y)) {
    g_ImGuiHitTest = func;
}

static void (*old_input)(void* event, void* exAb, void* exAc) = nullptr;
static int (*old_getWidth)(ANativeWindow* window) = nullptr;
static int (*old_getHeight)(ANativeWindow* window) = nullptr;

static void hook_input(void* event, void* exAb, void* exAc) {
    if (!g_Initialized) {
        if (old_input) old_input(event, exAb, exAc);
        return;
    }
    if (old_input) old_input(event, exAb, exAc);
    AInputEvent* inputEvent = (AInputEvent*)event;
    if (AInputEvent_getType(inputEvent) != AINPUT_EVENT_TYPE_MOTION) {
        g_TouchCount = 0;
        g_TouchPoints.clear();
        return;
    }
    
    int action = AMotionEvent_getAction(inputEvent);
    int actionMasked = action & AMOTION_EVENT_ACTION_MASK;
    int pointerIndex = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    int pointerCount = AMotionEvent_getPointerCount(inputEvent);
    int64_t eventTime = AMotionEvent_getEventTime(inputEvent);
    
    switch (actionMasked) {
        case AMOTION_EVENT_ACTION_DOWN:
        case AMOTION_EVENT_ACTION_POINTER_DOWN: {
            int id = AMotionEvent_getPointerId(inputEvent, pointerIndex);
            float x = AMotionEvent_getX(inputEvent, pointerIndex);
            float y = AMotionEvent_getY(inputEvent, pointerIndex);
            g_TouchPoints[id] = {id, x, y, true, eventTime};
            g_TouchCount = g_TouchPoints.size();
            bool hitImGui = g_ImGuiHitTest ? g_ImGuiHitTest(x, y) : false;
            if (!g_UiTouchController.uiControllerActive && hitImGui) {
                g_UiTouchController.uiControllerId = id;
                g_UiTouchController.uiControllerDownTime = eventTime;
                g_UiTouchController.uiControllerActive = true;
                auto& io = ImGui::GetIO();
                io.AddMousePosEvent(x, y);
                io.AddMouseButtonEvent(0, true);
            }
            break;
        }
        
        case AMOTION_EVENT_ACTION_MOVE: {
            for (int i = 0; i < pointerCount; i++) {
                int id = AMotionEvent_getPointerId(inputEvent, i);
                float x = AMotionEvent_getX(inputEvent, i);
                float y = AMotionEvent_getY(inputEvent, i);
                auto it = g_TouchPoints.find(id);
                if (it != g_TouchPoints.end()) {
                    it->second.x = x;
                    it->second.y = y;
                }
                if (g_UiTouchController.uiControllerActive && id == g_UiTouchController.uiControllerId) {
                    ImGui::GetIO().AddMousePosEvent(x, y);
                }
            }
            break;
        }
        
        case AMOTION_EVENT_ACTION_UP:
        case AMOTION_EVENT_ACTION_POINTER_UP: {
            int id = AMotionEvent_getPointerId(inputEvent, pointerIndex);
            if (g_UiTouchController.uiControllerActive && id == g_UiTouchController.uiControllerId) {
                ImGui::GetIO().AddMouseButtonEvent(0, false);
                int newControllerId = -1;
                int64_t earliestTime = INT64_MAX;
                for (const auto& [tid, pt] : g_TouchPoints) {
                    if (tid == id || !pt.down) continue;
                    if (g_ImGuiHitTest && g_ImGuiHitTest(pt.x, pt.y)) {
                        if (pt.downTime < earliestTime) {
                            earliestTime = pt.downTime;
                            newControllerId = tid;
                        }
                    }
                }
                if (newControllerId != -1) {
                    g_UiTouchController.uiControllerId = newControllerId;
                    g_UiTouchController.uiControllerDownTime = earliestTime;
                    auto& pt = g_TouchPoints[newControllerId];
                    ImGui::GetIO().AddMousePosEvent(pt.x, pt.y);
                    ImGui::GetIO().AddMouseButtonEvent(0, true);
                } else {
                    g_UiTouchController.uiControllerId = -1;
                    g_UiTouchController.uiControllerDownTime = 0;
                    g_UiTouchController.uiControllerActive = false;
                }
            }
            g_TouchPoints.erase(id);
            g_TouchCount = g_TouchPoints.size();
            break;
        }
        
        case AMOTION_EVENT_ACTION_CANCEL: {
            g_TouchPoints.clear();
            g_TouchCount = 0;
            if (g_UiTouchController.uiControllerActive) {
                ImGui::GetIO().AddMouseButtonEvent(0, false);
                g_UiTouchController.uiControllerId = -1;
                g_UiTouchController.uiControllerDownTime = 0;
                g_UiTouchController.uiControllerActive = false;
            }
            break;
        }
    }
}

static int hook_getWidth(ANativeWindow* window) {
    g_Egl.screenWidth = old_getWidth(window);
    return g_Egl.screenWidth;
}

static int hook_getHeight(ANativeWindow* window) {
    g_Egl.screenHeight = old_getHeight(window);
    return g_Egl.screenHeight;
}

static bool IsPointInImGuiWindow(float x, float y) {
    ImGuiContext& g = *GImGui;
    for (int i = 0; i < g.Windows.Size; i++) {
        ImGuiWindow* window = g.Windows[i];
        if (!window->Active || window->Hidden) continue;
        if (x >= window->Pos.x && x < window->Pos.x + window->Size.x &&
            y >= window->Pos.y && y < window->Pos.y + window->Size.y) {
            return true;
        }
    }
    if (g.OpenPopupStack.Size > 0) {
        ImGuiPopupData* popup = &g.OpenPopupStack.back();
        if (popup->Window) {
            ImGuiWindow* window = popup->Window;
            if (x >= window->Pos.x && x < window->Pos.x + window->Size.x &&
                y >= window->Pos.y && y < window->Pos.y + window->Size.y) {
                return true;
            }
        }
    }
    return false;
}