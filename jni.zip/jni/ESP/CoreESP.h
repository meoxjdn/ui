#pragma once
#include "../Include/对接.h"
#include "Offsets.h"
#include "MathUtils.h"
#include "../ImGui/imgui.h"

class CoreESP {
public:
    static void Draw(uintptr_t libbase, int w, int h) {
        ImDrawList* drawList = ImGui::GetBackgroundDrawList();
        
        // 1. 读取矩阵
        Matrix4x4 vMatrix = read<Matrix4x4>(libbase + Offsets::CameraManager_Static);
        
        // 2. 获取管理器和列表
        uintptr_t mgr = read<uintptr_t>(libbase + Offsets::KHPlayerManager_Static);
        if (!mgr) return;
        
        uintptr_t pList = read<uintptr_t>(mgr + Offsets::m_playerList);
        int size = read<int>(pList + Offsets::ListSize);
        uintptr_t items = read<uintptr_t>(pList + Offsets::ListItems);
        
        for (int i = 0; i < size; i++) {
            uintptr_t actor = read<uintptr_t>(items + Offsets::ArrayData + (i * 8));
            if (!actor) continue;

            // 3. 坐标转换
            Vector3 pos = read<Vector3>(actor + Offsets::ActorPosition);
            Vector2 screenPos;
            if (MathUtils::WorldToScreen(pos, vMatrix, w, h, screenPos)) {
                
                // 4. 读取技能 CD (以技能C为例)
                uintptr_t skillC = read<uintptr_t>(actor + Offsets::dynamicSkillC);
                uintptr_t group = read<uintptr_t>(skillC + Offsets::itemSkillGroup);
                uintptr_t infoList = read<uintptr_t>(group + Offsets::skillInfos);
                uintptr_t infoItems = read<uintptr_t>(infoList + Offsets::ListItems);
                uintptr_t firstInfo = read<uintptr_t>(infoItems + Offsets::ArrayData);
                
                int cdFrames = read<int>(firstInfo + Offsets::leftCd);
                
                // 绘制显示
                char buf[32];
                if (cdFrames > 0) {
                    sprintf(buf, "Skill C: %.1fs", cdFrames / 60.0f);
                    drawList->AddText({screenPos.x, screenPos.y}, ImColor(255, 0, 0), buf);
                } else {
                    drawList->AddText({screenPos.x, screenPos.y}, ImColor(0, 255, 0), "C: READY");
                }
            }
        }
    }
};
