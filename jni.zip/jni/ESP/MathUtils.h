#pragma once

struct Vector2 { float x, y; };
struct Vector3 { float x, y, z; };
struct Matrix4x4 { float m[16]; };

class MathUtils {
public:
    static bool WorldToScreen(Vector3 world_pos, Matrix4x4 matrix, int width, int height, Vector2& out) {
        float w = world_pos.x * matrix.m[3] + world_pos.y * matrix.m[7] + world_pos.z * matrix.m[11] + matrix.m[15];
        if (w < 0.1f) return false;

        float x = world_pos.x * matrix.m[0] + world_pos.y * matrix.m[4] + world_pos.z * matrix.m[8] + matrix.m[12];
        float y = world_pos.x * matrix.m[1] + world_pos.y * matrix.m[5] + world_pos.z * matrix.m[9] + matrix.m[13];

        out.x = (width / 2.0f) * (1.0f + x / w);
        out.y = (height / 2.0f) * (1.0f - y / w);
        return true;
    }
};
